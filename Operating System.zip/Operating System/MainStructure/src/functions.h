/*
 * functions.h
 *
 *  Created on: Oct. 2, 2018
 *      Author: JJ
 */

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_



#endif /* FUNCTIONS_H_ */

// calculator functions
void sub11(void);
void sub12(void);
void sub13(void);
void sub14(void);
void printA();
void printB();
void printC();
void sub31(void);
void sub32(void);
void sub41(void);
void sub42(void);

//sub1
void lunchsub1(int submenuId,int *key1);
void sub1Menu();
void displaysub1Menu(int menuId);

//sub2
void lunchsub2(int submenuId,int *key2);
void sub2Menu();
void displaysub2Menu(int menuId);

//sub3
void lunchsub3(int submenuId,int *key3);
void sub3Menu();
void displaysub3Menu(int menuId);

//sub4
void lunchsub4(int submenuId,int *key4);
void sub4Menu();
void displaysub4Menu(int menuId);


//lunches the main menu choice
void lunch(int menuId,int *key);
void displayMainMenu(int menuId);

